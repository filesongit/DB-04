/* eslint-disable react/prop-types */
import { Navigate } from "react-router-dom"

const Privateroute = (props) => {
    return <div>{ props.isLoggedIn ? props.children : <Navigate to={"/"} /> }</div>
}

export default Privateroute