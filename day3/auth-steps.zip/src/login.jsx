import { useNavigate } from "react-router-dom";
import Cookies from "js-cookie";

/* eslint-disable react/prop-types */
let LoginComp = () => {
    const navigate = useNavigate();
    return <div className="card">
                <div className="card-body">
                    <h2>Login Component</h2>
                    <button onClick={()=> { Cookies.set("user","vijay") }} className="btn btn-primary">Set Cookie</button>
                    &nbsp;
                    <button onClick={()=> { navigate("/");}} className="btn btn-primary">Home</button>
                </div>
            </div>
};

export default LoginComp;