import { useState } from "react";
import HomeComp from "./home";
import LoginComp from "./login";
import ProfileComp from "./profile";
import RegisterComp from "./register";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Privateroute from "./privateroute";
import Cookies from "js-cookie";

let App = () => {
    let [isLoggedIn, setLogin] = useState(true);
    let changeLoggedStatus = (val) => {
        let user = Cookies.get("user");
        if(user){
            setLogin(val);
        }
    }
    return <div className="container">
        <h1>Welcome to React Authorisation | Authentication</h1>
        <BrowserRouter>
            <Routes>
                <Route path="/" element={<HomeComp log={isLoggedIn} changeLoggedStatus={changeLoggedStatus}/>} />
                <Route path="/login" element={<LoginComp />}/>
                <Route path="/register" element={<RegisterComp/>}/>
                <Route path="/profile" element={ <Privateroute isLoggedIn={isLoggedIn}><ProfileComp log={isLoggedIn} changeLoggedStatus={changeLoggedStatus} /></Privateroute> }/>
           </Routes>
        </BrowserRouter>
    </div>
};



export default App;