let RegisterComp = () => {
    return <div className="card">
                <div className="card-body">
                    <h2>Register Component</h2>
                    <button className="btn btn-primary">Register</button>
                </div>
            </div>
};

export default RegisterComp;