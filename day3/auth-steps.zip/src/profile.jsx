import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Cookies from "js-cookie";

/* eslint-disable react/prop-types */
let ProfileComp = (props) => {
    const navigate = useNavigate();
    let [userinfo, setUser] = useState("")
    useEffect(function(){
        let user = Cookies.get("user");
        if(!user){
            navigate("/");
        }else{
            setUser(user)
        }
    },[])
    return <div className="card">
                <div className="card-body">
                    <h2>Profile Component | { props.log ? "true" : "false"}</h2>
                    <h3>User is { userinfo }</h3>
                    <button onClick={() => {
                        props.changeLoggedStatus(false);
                        Cookies.remove("user")
                        navigate("/")
                        }} className="btn btn-danger">Logout</button>
                        &nbsp;
                        <button onClick={()=> { navigate("/");}} className="btn btn-primary">Home</button>
                </div>
            </div>
};

export default ProfileComp;