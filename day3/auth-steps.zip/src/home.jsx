/* eslint-disable react/prop-types */
import { useNavigate } from "react-router-dom";
let HomeComp = (props) => {
    const navigate = useNavigate();
    return <div className="card">
                <div className="card-body">
                    <h2>Home Component { props.log ? "true" : "false" }</h2>
                    <button onClick={()=> props.changeLoggedStatus(!props.log)} className="btn btn-primary">Set Login</button>
                    &nbsp;
                    &nbsp;
                    <button onClick={()=> navigate("/login")} className="btn btn-primary">Login Page</button>
                    &nbsp;
                    &nbsp;
                    <button onClick={()=> navigate("/register")} className="btn btn-primary">Register Page</button>
                    &nbsp;
                    &nbsp;
                    <button onClick={()=> navigate("/profile")} className="btn btn-primary">Profile Page</button>
                </div>
            </div>
};

export default HomeComp;