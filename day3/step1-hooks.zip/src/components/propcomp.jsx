function PropComp({title, version, power, children}) {
    return <div>
             <h3>Props</h3>
             <ul>
                <li>Title : {title}</li>
                <li>Version : {version}</li>
                <li>Power : {power}</li>
             </ul>
             <hr />
             { children }
           </div>
  }
  
  export default PropComp
  