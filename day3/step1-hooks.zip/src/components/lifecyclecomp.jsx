import { useEffect, useState } from "react";
import axios from "axios";

function LifeCycleComp() {
    let [version, setVersion] = useState(0);
    let [users, setUsers] = useState([]);
    // mount
    useEffect(()=>{
        console.log("LifeCycleComp was mounted");
        axios.get("http://jsonplaceholder.typicode.com/users")
        .then(res => setUsers(res.data) )
        .catch(err => console.log("Error ", err))
    },[])

    // update
    useEffect(()=>{
        console.log("LifeCycleComp is updated its version to ", version);
    },[version])
    
    // unmount
    useEffect(()=>{
        return () => console.log("LifeCycleComp is unmounted");
    },[])

    return <div>
             <h3>LifeCycle Hooks</h3>
             <button onClick={() => setVersion(Math.round(Math.random() * 1000 ))}>Change Version</button>
             <h4>Version { version }</h4>
             <table className="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>Sl #</th>
                        <th>Name</th>
                        <th>User Name</th>
                        <th>eMail</th>
                        <th>Phone</th>
                        <th>Website</th>
                    </tr>
                </thead>
                <tbody>
                    { users.map( val => <tr key={ val.id }>
                                            <td>{ val.id }</td>
                                            <td>{ val.name }</td>
                                            <td>{ val.username }</td>
                                            <td>{ val.email }</td>
                                            <td>{ val.phone }</td>
                                            <td>{ val.website }</td>
                                        </tr>  )}
                    
                </tbody>
             </table>
           </div>
}
export default LifeCycleComp  