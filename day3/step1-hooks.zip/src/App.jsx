/* 
Class Component known as smart or stateful components
-----------------------------------------------------
forceUpdate
state management methods
lifecycle events
HOC
Error Boundries

Function Component known as dumb or stateless components
-----------------------------------------------------
fast 
hooks
Hot reloading
easy on the developer
*/

import { useEffect, useState } from "react"
import LifeCycleComp from "./components/lifecyclecomp"
import PropComp from "./components/propcomp"
import StateComp from "./components/statecomp"

function App() {
  let [show, setShow] = useState(true)
  // mount
  useEffect(()=>{
    console.log("App was mounted");
  },[])

  return <div className="container">
           <h2>React Function Components</h2>
           <PropComp title="DB Training for Batch 04" version="1010" power="7">
              <button>Click Me</button>
              <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Modi laudantium ipsum voluptas alias atque ex asperiores, nisi dicta eos, dignissimos cum veniam voluptatem corporis unde, quod eveniet repellendus aliquam a?
              </p>
           </PropComp>
           <hr />
           <StateComp/>
           <hr />
           <button onClick={() => setShow(!show)}>Show / Hide</button>
           { show ? <LifeCycleComp/> : "lifecycle component is hidden" }
         </div>
}

export default App
