import { Provider } from "react-redux"
import HeroComp from "./components/herocomp"
import store from "./redux/store"
import HeroShowcaseComp from "./components/displayhero"

function App() {
  return <div className="container">
          <h1>React with Redux</h1>
          <Provider store={store}>
            <HeroComp/>
            <hr />
            <HeroShowcaseComp/>
          </Provider>
         </div>
}

export default App
