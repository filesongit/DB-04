import {legacy_createStore} from "redux";
import { heroReducer } from "./hero/reducers/hero.reducers";

const store = legacy_createStore(heroReducer);

export default store;