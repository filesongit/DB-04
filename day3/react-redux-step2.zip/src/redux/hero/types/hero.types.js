const ADD_HERO = "ADD_HERO";

export { ADD_HERO };