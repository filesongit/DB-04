import { useSelector } from "react-redux"

function HeroShowcaseComp() {
    let numberOfHeroes = useSelector( state => state.numberOfHeroes );
    return <div>
            <h3>ShowCase Avengers</h3>
            <h4>Avengers available : {numberOfHeroes}</h4>
           </div>
  }
  
  export default HeroShowcaseComp