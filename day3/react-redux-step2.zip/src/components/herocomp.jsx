import { useDispatch, useSelector } from "react-redux"
import { addHero } from "../redux";

function HeroComp() {
    let numberOfHeroes = useSelector( state => state.numberOfHeroes );
    let dispatch = useDispatch();
    return <div>
            <h3>Manage Avengers</h3>
            <h4>Avengers added so far : {numberOfHeroes}</h4>
            <button onClick={()=> dispatch(addHero())} className="btn btn-primary">Add Avenger</button>
           </div>
  }
  
  export default HeroComp