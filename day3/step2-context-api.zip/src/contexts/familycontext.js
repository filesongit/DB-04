import React from "react";

let FamilyContext = React.createContext();

/* 
// consume the data
FamilyContext.Consumer
// provide the data
FamilyContext.Provider
// provide an alias name to the context
FamilyContext.displayName 
*/

export default FamilyContext;