import GrandParentComp from "./components/grandparentcomp"

function App() {
  return <div className="container">
           <h2>React State Management Example</h2>
           <GrandParentComp/>
         </div>
}

export default App
