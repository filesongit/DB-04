import { useContext } from "react"
import FamilyContext from "../contexts/familycontext"

function CousinComp() {
    let {power} = useContext(FamilyContext);
    return <div className="card">
            <div className="card-body">
                    <h3 className="card-title">Cousin Component</h3>
                    <div>
                        Cousin Component content comes here
                    </div>
                    <ul>
                        <li>Power : {power}</li>
                    </ul>
            </div>
           </div>
  }
  
  export default CousinComp
  