import ChildComp from "./childcomp"

function ParentComp() {
    return <div className="card">
                <div className="card-body">
                 <h3 className="card-title">Parent Component</h3>
                    <div>
                        Parent Component content comes here
                    </div>
                    <ChildComp/>
                </div>
           </div>
  }
  
  export default ParentComp
  