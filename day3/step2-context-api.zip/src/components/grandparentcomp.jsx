import { useState } from "react"
import ParentComp from "./parentcomp"
import FamilyContext from "../contexts/familycontext"
import CousinComp from "./cousincomp"

function GrandParentComp() {
    let [state, setState] = useState({
        power : 0,
        version : 0,
        message : "default message"
    })
    return <div className="card">
<div className="card-body">
    <h3 className="card-title">Grand Parent Component</h3>
    <div>
        Grand Parent Component content comes here
        <br />
        <br />
        <label htmlFor="msg">Change Message &nbsp; </label>
        <input onInput={(evt) => setState({...state, message : evt.target.value})} id="msg" type="text" />
        <br />
        <br />
        <input type="button" onClick={() => setState({...state, version : Math.round( Math.random() * 1000 )})} defaultValue="Set Random Version" />
        <br />
        <br />
        <label htmlFor="msg">Change Power  &nbsp; </label>
        <input onInput={(evt) => setState({...state, power : Number(evt.target.value)})} type="range" />
    </div>
    <ul>
        <li>Power : {state.power}</li>
        <li>Version : {state.version}</li>
        <li>Message : {state.message}</li>
    </ul>
    {/* <ParentComp {...state}/> */}
    <FamilyContext.Provider value={state}>
        <ParentComp/>
        <CousinComp/>
    </FamilyContext.Provider>
    </div>
</div>
  }
  
  export default GrandParentComp
  