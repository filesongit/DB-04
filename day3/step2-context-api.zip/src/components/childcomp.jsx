import { useContext } from "react"
import FamilyContext from "../contexts/familycontext"

function ChildComp() {
    let {power, version, message} = useContext(FamilyContext);
    return <div className="card">
            <div className="card-body">
                    <h3 className="card-title">Child Component</h3>
                    <div>
                        Child Component content comes here
                    </div>
                    <ul>
                        <li>Power : {power}</li>
                        <li>Version : {version}</li>
                        <li>Message : {message}</li>
                    </ul>
            </div>
           </div>
  }
  
  export default ChildComp
  