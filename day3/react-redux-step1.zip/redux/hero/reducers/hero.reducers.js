import { ADD_HERO } from "../types/hero.types";

let intialHeroState = {
    numberOfHeroes : 0
};

let heroReducer = (state = intialHeroState, action) => {
    switch(action.type){
        case ADD_HERO : return { numberOfHeroes : state.numberOfHeroes + 1 }
        default : return state
    }
};

export { heroReducer };