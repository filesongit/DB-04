import { useState } from "react"
import GrandParentComp from "./components/grandparentcomp"
import GeneralContext from "./contexts/generalcontext"

function App() {
  let [timer, setTimer] = useState(5);
  setInterval(() => setTimer(new Date().getMilliseconds()) , 100)
  return <div className="container">
           <h2>React State Management Example</h2>
           <GeneralContext.Provider value={timer}>
             <GrandParentComp/>
           </GeneralContext.Provider>
         </div>
}

export default App
