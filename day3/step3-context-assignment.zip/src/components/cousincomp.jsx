import { useContext } from "react"
import FamilyContext from "../contexts/familycontext"
import GeneralContext from "../contexts/generalcontext";

function CousinComp() {
    let {power} = useContext(FamilyContext);
    let timer = useContext(GeneralContext);
    return <div className="card">
            <div className="card-body">
                    <h3 className="card-title">Cousin Component</h3>
                    <div>
                        Cousin Component content comes here
                    </div>
                    <ul>
                        <li>Power : {power}</li>
                        <li>Timer : {timer}</li>
                    </ul>
            </div>
           </div>
  }
  
  export default CousinComp
  