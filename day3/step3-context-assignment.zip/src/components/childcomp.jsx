import { useContext } from "react"
import FamilyContext from "../contexts/familycontext"
import GeneralContext from "../contexts/generalcontext";

function ChildComp() {
    let {power, version, message} = useContext(FamilyContext);
    let timer = useContext(GeneralContext);
    return <div className="card">
            <div className="card-body">
                    <h3 className="card-title">Child Component</h3>
                    <div>
                        Child Component content comes here
                    </div>
                    <ul>
                        <li>Power : {power}</li>
                        <li>Version : {version}</li>
                        <li>Message : {message}</li>
                        <li>Timer : {timer}</li>
                    </ul>
            </div>
           </div>
  }
  
  export default ChildComp
  