import React from "react";

let GeneralContext = React.createContext();

export default GeneralContext;