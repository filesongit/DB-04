/* eslint-disable testing-library/prefer-screen-queries */
import { render, fireEvent } from '@testing-library/react';
import App from './App';

describe('Power component', () => {
 it('increments count when the increment button is clicked', () => {
    const { getByText } = render(<App />);
    const countElement = getByText('Power: 0');
    const incrementButton = getByText('Increase Power');
    fireEvent.click(incrementButton);
    expect(countElement.textContent).toBe('Power: 1');
    fireEvent.click(incrementButton);
    fireEvent.click(incrementButton);
    expect(countElement.textContent).toBe('Power: 3');
  });
});