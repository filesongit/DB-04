import { useState } from "react";

function App() {
  const [power, setPower] = useState(0);

  const increasePower = () => {
    setPower(power + 1);
  };
  return (
    <div>
      <p>Power: {power}</p>
      <button onClick={increasePower}>Increase Power</button>
    </div>
  );
}

export default App;