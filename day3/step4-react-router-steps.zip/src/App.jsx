import { BrowserRouter, Route, Routes, Link } from "react-router-dom";
import HomeComp from "./components/home";
import { useState } from "react";
import BatmanComp from "./components/batman";
import SupermanComp from "./components/superman";
import WonderWomenComp from "./components/wonderwomen";
import NotFoundComp from "./components/notfound";
function App() {
  const [count, setCount] = useState(0)
  return <div>
          <h1>Routing Example</h1>
          {/* 
          <ul>
            <li> <a href="/">Home</a> </li>
            <li> <a href="/batman">Batman</a> </li>
            <li> <a href="/superman">Superman</a> </li>
            <li> <a href="/wonderwomen">Wonder Women</a> </li>
            <li> <a href="/flash">Flash</a> </li>
            <li> <a href="/hulk">Hulk</a> </li>
          </ul> 
          */}
          <BrowserRouter>
            <ul>
              <li> <Link to="/">Home</Link> </li>
              <li> <Link to="/batman">Batman</Link> </li>
              <li> <Link to="/superman">Superman</Link> </li>
              <li> <Link to="/wonderwomen">Wonder Women</Link> </li>
              <li> <Link to="/flash">Flash</Link> </li>
              <li> <Link to="/hulk">Hulk</Link> </li>
            </ul>
            <Routes>
              <Route path="/" element={<HomeComp/>} />
              <Route path="/batman" element={<BatmanComp/>} />
              <Route path="/superman" element={<SupermanComp/>} />
              <Route path="/wonderwomen" element={<WonderWomenComp/>} />
              <Route path="/flash" element={<BatmanComp/>}/>
              <Route path="*" element={<NotFoundComp/>} />
            </Routes>
          </BrowserRouter>
        </div>
}

export default App
