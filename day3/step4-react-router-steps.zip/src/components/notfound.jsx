function NotFoundComp() {
    return <div>
            <h2>404 | Page NotFound Component</h2>
          </div>
  }
  
  export default NotFoundComp