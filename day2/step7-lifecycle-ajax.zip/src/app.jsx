import { Component } from "react";
import ChildComp from "./components/childcomp";
import axios from "axios";


class App extends Component{
    state = {
        show : true,
        version : 0,
        users : []
    }
    constructor(){
        super();
        console.log("App Component's constructor was called")
    }
    render(){
        console.log("App Component's render was called")
        return <div className="container">
                    <h2>Class Component Lifecycle | { this.state.version }</h2>
                    <label htmlFor="showhide">Show / Hide</label>
                    <input checked={this.state.show} onChange={() => this.setState({ show : !this.state.show })} type="checkbox" id="showhide" />
                    <br />
                    <button className="btn btn-primary" onClick={() => this.setState({ version : Math.round(Math.random() * 1000 ) })}>Change Version</button>
                    <hr />
                    {this.state.show ? <ChildComp data={ this.state.users } version={this.state.version}/> : "child component is unmounted"}
               </div>
    }
    componentDidMount(){
        console.log("App Component's componentDidMount was called");
        axios.get("https://reqres.in/api/users?page=1")
        .then( res => this.setState({ users : res.data.data }))
        .catch( error => console.log("Error ", error ))
    }

}

export default App;