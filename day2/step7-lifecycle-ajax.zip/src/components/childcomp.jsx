/* eslint-disable react/no-unescaped-entities */
/* eslint-disable react/prop-types */
import { Component } from "react";

class ChildComp extends Component{
    constructor(){
        super();
        console.log("ChildComp's constructor was called")
    }
    render(){
        console.log("ChildComp's render was called")
        return <div className="container">
                    <h3>Child Component</h3>
                    <h4>Parent's version {this.props.version }</h4>
                    <table className="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>Sl #</th>
                                <th>Photo</th>
                                <th>Full Name</th>
                                <th>eMail</th>
                            </tr>
                        </thead>
                        <tbody>
                            { this.props.data.map((val) => <tr key={val.id}> 
                                <td>{val.id}</td> 
                                <td>
                                    <img src={val.avatar} alt={val.first_name+" "+val.last_name} />
                                </td> 
                                <td>{val.first_name+" "+val.last_name}</td> 
                                <td>{val.email}</td> 
                                </tr>
                            ) }
                        </tbody>
                    </table>
               </div> 
    }
    componentDidUpdate(){
        console.log("ChildComp's componentDidUpdate was called");
    }
    componentDidMount(){
        console.log("ChildComp's componentDidMount was called")
    }
    componentWillUnmount(){
        console.log("ChildComp's componentWillUnmount was called")
    }
}

export default ChildComp;