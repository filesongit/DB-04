import { Component } from "react";
import HeroComp from "./herolist";

let justiceleague = ["Batman","Superman","Flash","Wonder Women", "Aquaman", "Cyborg"];
let avengers = ["Ironman","Dr Strange", "Thor", "Hulk", "Captain America"];
let indicheroes = ["Shaktiman", "Chota Bheem", "Krish"];

class App extends Component{
    render(){
        return <div>
                    <HeroComp title="Avengers" list={avengers}/>
                    <HeroComp title="Justice League" list={justiceleague}/>
                    <HeroComp title="Indic Heroes" list={indicheroes}/>
               </div>
    }
 }

 export default App;