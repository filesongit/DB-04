import { Component } from "react"
class HeroComp extends Component{
    render(){
        return <div>
                    <h1> {this.props.title} Heroes</h1>
                    <ul>{ this.props.list.map((val,idx) => <li className="box" key={idx}>{val}</li> ) }</ul>
               </div> 
    }
 }

 export default HeroComp;