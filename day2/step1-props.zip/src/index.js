import ReactDOM from "react-dom/client";
import App from "./components/app";

/* 
class MyComp extends React.Component{
    avengers = ["Batman","Superman","Flash","Wonder Women"]
    render(){
        return <ul>{ this.avengers.map((val,idx) => <li className="box" key={idx}>{val}</li> ) }</ul> 
    }
 }

let FunComp = () => {
    let avengers = ["Ironman","Hulk","Thor","Black Panther", "Black Widow"]
    return <ul>{ avengers.map((val,idx) => <li className="box" key={idx}>{val}</li> ) }</ul> 
} 
*/

ReactDOM
.createRoot(document.getElementById("root"))
.render(<App/>);