import React, { Component } from "react";

class App extends Component{
    state = {
        heroes : []
    };
    ipref = React.createRef();
    render(){
        console.log("render was called")
        return <div>
                    <h1>Heroes</h1>
                    <input ref={this.ipref} type="text" />
                    <button onClick={()=> {
                        this.setState({ heroes : [...this.state.heroes, this.ipref.current.value]});
                    }} >Add Hero</button>
                    <ul>{ this.state.heroes.map((val,idx) => <li className="box" key={idx}>{val}</li> ) }</ul>
                </div> 
    }
 }

 export default App;