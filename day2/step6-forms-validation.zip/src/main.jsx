import ReactDOM from 'react-dom/client'
import App from './app.jsx'

ReactDOM
.createRoot(document.getElementById('root'))
.render(<App />)

/* 

npm create vite@latest step1 -- --template react
cd step1
npm i
npm run dev 

*/