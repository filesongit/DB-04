import { Component } from "react";
import "./assets/formstyle.css";

class App extends Component{
    state = {
        userinfo : {
            firstname : "",
            lastname : "",
            age : 0
        },
        showerrors : {
            firstname_error : "",
            lastname_error : "",
            age_error : ""
        }
    }
    render(){
        return <div className="container">
                    <h2>User Registeration App</h2>
                    <hr />
                    <div className="mb-3">
                        <label htmlFor="firstname" className="form-label">First Name</label>
                        <input onChange={ this.userInfoHandler } value={this.state.userinfo.firstname} className="form-control" id="firstname"/>
                        { this.state.showerrors.firstname_error != "" && <div className="form-text">{ this.state.showerrors.firstname_error }</div> }
                    </div>
                    <div className="mb-3">
                        <label htmlFor="lastname" className="form-label">Last Name</label>
                        <input onChange={ this.userInfoHandler } value={this.state.userinfo.lastname} className="form-control" id="lastname"/>
                        { this.state.showerrors.lastname_error != "" && <div className="form-text">{ this.state.showerrors.lastname_error }</div>}
                    </div>
                    <div className="mb-3">
                        <label htmlFor="age" className="form-label">Age</label>
                        <input onChange={ this.userInfoHandler } value={this.state.userinfo.age} type="number" className="form-control" id="age"/>
                        {this.state.showerrors.age_error != "" && <div className="form-text">{ this.state.showerrors.age_error }</div>}
                    </div>
                    <button onClick={ this.setValidations } className="btn btn-primary">Register</button>
                    <hr />
                    <ul>
                        <li>First Name { this.state.userinfo.firstname }</li>
                        <li>Last Name { this.state.userinfo.lastname }</li>
                        <li>Age { this.state.userinfo.age }</li>
                    </ul>
               </div>
    }
    /* firstnameHandler = (event) => {
        this.setState(
            {...this.state, 
                userinfo : {
                ...this.state.userinfo,
                firstname : event.target.value
                }
            })
        }
    lastnameHandler = (event) => {
        this.setState(
            {...this.state, 
                userinfo : {
                ...this.state.userinfo,
                lastname : event.target.value
                }
            })

    }
    ageHandler = (event) => {
        this.setState(
            {...this.state, 
                userinfo : {
                ...this.state.userinfo,
                age : event.target.value
                }
            })
    } */
    userInfoHandler = (event) => {
        this.setState(
            {...this.state, 
                userinfo : {
                ...this.state.userinfo,
                [event.target.id] : event.target.value
                }
            })
    }

    setValidations = () => {
        //set error for first name
        this.setState(
            {...this.state, 
                showerrors : {
                ...this.state.showerrors,
                firstname_error : this.state.userinfo.firstname === "" && "you must fill your first name" ,
                lastname_error : this.state.userinfo.lastname === "" && "you must fill your last name",
                age_error : this.state.userinfo.age == 0 ? "you must fill your age" : ""
                }
            });
    }
}

export default App;