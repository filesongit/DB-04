let FunComponent = (props) => {
    // dumb or stateless component
    console.log("FunComponent was rendered")
    return <div>
                <h2>I am a Function Component</h2>
                <h3>First Message : {props.firstinfo}</h3>
                <h3>Second Message : {props.secondinfo}</h3>
            </div> 
}
 export default FunComponent;