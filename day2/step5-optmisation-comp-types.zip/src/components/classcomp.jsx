import React, { Component } from "react";

class ClassComponent extends Component{
    // stateful
    state = {
        power : 0
    }
    render(){
        console.log("ClassComponent was rendered")
        return <div>
                    <h2>I am a Class Component</h2>
                    <h3>First Message : {this.props.firstinfo}</h3>
                    <h3>Second Message : {this.props.secondinfo}</h3>
               </div> 
    }
 }

 export default ClassComponent;