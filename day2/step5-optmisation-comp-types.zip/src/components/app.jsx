import React, { Component } from "react";
import ClassComponent from "./classcomp";
import FunComponent from "./funcomp";
import OptiClassComponent from "./optimizedClassComp";
import FunMemoComponent from "./memo-funcomp";

class App extends Component{
    state = {
        message1 : "",
        message2 : ""
    }
    ipref1 = React.createRef();
    ipref2 = React.createRef();
    render(){
        return <div>
                    <h1>Component Types</h1>
                    <input ref={this.ipref1} type="text" />
                    <button onClick={()=> this.setState({message1 : this.ipref1.current.value})}>Change First Message</button>
                    <br />
                    <input ref={this.ipref2} type="text" />
                    <button onClick={()=> this.setState({message2 : this.ipref2.current.value})}>Change Second Message</button>
                    <hr />
                    <ClassComponent firstinfo={this.state.message1} secondinfo={this.state.message2}/>
                    <FunComponent firstinfo={this.state.message1} secondinfo={this.state.message2}/>
                    <OptiClassComponent firstinfo={this.state.message1} secondinfo={this.state.message2}/>
                    <FunMemoComponent firstinfo={this.state.message1} secondinfo={this.state.message2}/>
               </div> 
    }
 }

 export default App;