import React, { PureComponent } from "react";

class OptiClassComponent extends PureComponent{
    // stateful
    state = {
        power : 0
    }
    render(){
        console.log("Optimized Class Component was rendered")
        return <div>
                    <h2>I am a Pure Class Component</h2>
                    <h3>First Message : {this.props.firstinfo}</h3>
                    <h3>Second Message : {this.props.secondinfo}</h3>
               </div> 
    }
 }

 export default OptiClassComponent;